"""Configure access key and secret key to use Product-Advertising-API in different locale."""


CONFIG_AWS ={
             'US':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             'associate_tag': 'starmerx067-20',
             'locale': 'us'
             },
             'UK':{
             'access_key': 'AKIAJB4U37FAYGYCCCKA',
             'secret_key': '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',
             'associate_tag': 'starmerx21',
             'locale': 'uk'
             },
             'DE':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             'associate_tag': 'starmerx03-21',
             'locale': 'de'
             },
             'FR':{},
             'IN':{},
             'IT':{},
             'ES':{},
             'CA':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             'associate_tag': 'starmerx07-20',
             'locale': 'ca'
             },
             'CN':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             'associate_tag': 'starmerx-23',
             'locale': 'cn'
             },
             'JP':{
            'access_key': 'AKIAILNAHWCWQFN3PHLQ',
             'secret_key': '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',
             'associate_tag': 'starmerx-23',
             'locale': 'jp'
             },
             'MX':{
            'access_key': 'AKIAILNAHWCWQFN3PHLQ',
             'secret_key': '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',
             'associate_tag': 'starmerx067-20',
             'locale': 'mx'
             },
             'MX':{
            'access_key': 'AKIAILNAHWCWQFN3PHLQ',
             'secret_key': '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',
             'associate_tag': 'starmerx067-20',
             'locale': 'mx'
             },
              'ES':{
            'access_key': 'AKIAILNAHWCWQFN3PHLQ',
             'secret_key': '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',
             'associate_tag': 'starmerx067-20',
             'locale': 'es'
             },
             }



#CONFIG_MWS = [
#              {
##             'access_key': 'AKIAILNAHWCWQFN3PHLQ',
##             'secret_key': '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',
#             
#               
#             'access_key': 'AKIAI4QSPO5ISDC2GJYQ',
#             'secret_key': '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',
#             },
##              {
##            'access_key': 'AKIAI54VHERUT2MIBHBA',
##             'secret_key': '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',
##                }
#              ]
CONFIG_MWS = {
          'US':{
             'access_key': 'AKIAI4QSPO5ISDC2GJYQ',
             'secret_key': '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',
             },
         'UK':{
             'access_key': 'AKIAJB4U37FAYGYCCCKA',
             'secret_key': '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',
             },
         'DE':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             },
         'FR':{},
         'IN':{},
         'IT':{},
         'ES':{},
         'CA':{
             'access_key': 'AKIAI4QSPO5ISDC2GJYQ',
             'secret_key': '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',
             },
             'CN':{
             'access_key': 'AKIAIFGBOQZTPGAASV3Q',
             'secret_key': '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',
             },
             'JP':{
            'access_key': 'AKIAILNAHWCWQFN3PHLQ',
             'secret_key': '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',
             }
              }
CONFIG_MPI ={
            "CA" : "A2EUQ1WTGCTBG2",
            "US" : "ATVPDKIKX0DER",
            "DE" : "A1PA6795UKMFR9",
            "ES" : "A1RKKUPIHCS9HS",
            "FR" : "A13V1IB3VIYZZH",
            "IN" : "A21TJRUUN4KGV",
            "IT" : "APJ6JRA9NG5V4",
            "UK" : "A1F83G8C2ARO7P",
            "JP" : "A1VC38T7YXB528",
            "CN" : "AAHKV2X7AFYLW"             
            }
CATEGORY_ROOT = {
            "CA" : ['3561346011','6205124011','927726','962454','14113311','677211011','927726','6205177011','2972705011','2206275011','6205499011','962454','6205514011','3234171','3323751','6205517011','962072','962454','110218011'],
            "US" : ['1036592','2619525011','2617941011','15690151','165796011','11055981','1000','301668','4991425011','195208011','2625373011','172282','3580501','16310101','3760931','285080','228239','3880591','133141011','284507','2972638011','599872','10304191','2350149011','195211011','301668','11091801','1084128','286168','541966','12923371','502394','409488','3375251','468240','165793011','404272','130','468642','377110011','508494','13900851'],
            "DE" : ['78689031','78191031','357577011','64257031','541686','542676','547664','569604','54071011','340846031','64257031','10925241','327473011','530484031','3169011','213083031','2454118031','1161658','1661648031','77195031','542676','340849031','192416031','10925051','569604','569604','542064','541708','16435121','12950661','547082','547664','541708','193708031'],
            "ES" : ['1951051031','1703495031','599364031','599379031','667049031','599367031','530484031','599391031','1661649031','1748200031','599373031','1571262031','599376031','2454136031','599385031','599382031','599388031'],
            "FR" : ['340855031','1571265031','206617031','197858031','468256','537366','578608','1058082','69633011','197861031','590748031','193711031','818936031','57686031','213080031','2454145031','1661654031','206442031','537366','340862031','192420031','1571268031','215934031','548012','548014','548014','578610','578608','548014','60937031'],
            "IN" : ['976389031','976416031','976419031','976442031','1951048031','976392031','1350380031','1350387031'],
            "IT" : ['1571280031','1571286031','411663031','412606031','412609031','433842031','635016031','818937031','524015031','1571292031','2454148031','1661660031','1748203031','412600031','524006031','412612031','523997031','412603031','524009031'],
            "UK" : ['83451031','248877031','60032031','66280031','1025612','505510','283926','560800','340834031','66280031','11052591','2016929051','193717031','341677031','11052591','213077031','2454166031','1661657031','77198031','505510','340837031','560800','11052591','1025614','1025616','319530011','11052591','712832','283926','283926','1025616','595312'],
            "JP" : ['361299011','2277724051','2017304051','13331821','52391051','465610','562032','562002','3210991','388316011','57239051','161669011','13331821','85896051','2250738051','3839151','2381130051','2128134051','562032','2123629051','2016926051','637630','14304371','13331821','2130989051','561972','637872','324025011'],
            "CN" : ['2016156051','80207071','1947899051','746776051','658390051','2016116051','2127215051','852803051','2016126051','1952920051','816482051','116087071','899280051','754386051','2127218051','2127221051','118863071','755653051','2029189051','863872051','836312051','647070051','2016136051','897415051','1953164051']    
                 }

LOCALE = 'us'
ASSOCIATE_TAG = 'Version="2010-12-01"'


SECRET_ACCESS1 = [
    {'acc': 'AKIAIEH6LNUK425Y7Q2Q',
  'sec': 'QqBejVRxyQU4ydefT0WHzvf/HKNwasoCk583qZZf'},
 {'acc': 'AKIAJDZNROKLVJKUCI3Q',
  'sec': 'SftKU70LhXFT8nnkt0efta845Lo5C4vFkiM7fiGT'},
 {'acc': 'AKIAIO35ODXH6KSCGHEQ',
  'sec': 'b9gTPlw23p46kb1719hhnxa1rB2JdaDFLjHXzyxK'},
 {'acc': 'AKIAJLP7FULC4DHGHTRA',
  'sec': '+3xyKrpe6J1bWIXNsqzl74FABQjVoMqD3a9d3gjL'},
 {'acc': 'AKIAJQWGOK3GT64YEVUA',
  'sec': 'VTit0mCnvc9Kb+t2rCc6RvhuZDILvvZTLfmM/5ss'},
 {'acc': 'AKIAI5G5JMCZTPPU5BVA',
  'sec': 'm24TTHYF6xq2XWkaRrxCGRVPE9zdJmevIP8rBQY9'},
 {'acc': 'AKIAIH4XYL6PRFN3OHCA',
  'sec': 'vGnrDmhhhHWMRxv44U/itYMNbVUMdxKhv/Jy1Y4r'},
 {'acc': 'AKIAJLQU44TAUOR2ATUA',
  'sec': '7U6ZYtvg8+H4uHmX6GqVVJRHHUjlv9JrRNVyqXEs'},
 {'acc': 'AKIAJ4YAHRAVB5A6XMSA',
  'sec': '1f+lsRmRWTcAZ0nBO1VmddbX0bnjJ0lC1v3kn7fJ'},
 {'acc': 'AKIAJLRGLSQAR2DAHX2A',
  'sec': 'g01XrWzOd0aawqhUIWVWT8qF7LgdwjlaZobPJK3P'},
 {'acc': 'AKIAIAHJLZ25OOBGIHEQ',
  'sec': 'dwuvlTagw89XbKh7Z2kJHvf0iO5PAJX2z9MrHAyn'},
 {'acc': 'AKIAJODO3EBT6OTMZBDA',
  'sec': '3SpWghDaX7w3vaLGadcFpdl14YHO+fByggNEfAcM'},
 {'acc': 'AKIAJF4RVJI57Y5CJFTQ',
  'sec': '2/Fy12c8ArZMH1VmxYDzSgYdQrPRL7ebilSkRYX6'},
 {'acc': 'AKIAIQWTSSFPM6F36HSA',
  'sec': 'zfR7f7SC5mW2dvlp5HuNHq5cTnUQaOWrQ3clTpdM'},
 {'acc': 'AKIAIU6PU2EITQXB2PTA',
  'sec': 'x3+buQrzOtcssayyobXkFuLFn4+GJpsKEzLPG98R'},
 {'acc': 'AKIAILUTCTZ7OYFLAVTA',
  'sec': 'rerTdWAVXsflW0ecaMcv/E9U0Ul/pOm+75y1hWjE'},
 {'acc': 'AKIAID7EQCA2JIQWPFQA',
  'sec': 'NwmaPfgSAiE4cC+UQbASZ/KxFKp+oKMT/dUKPr0n'},
 {'acc': 'AKIAJ4JYQLHTWDIY5BMQ',
  'sec': 'PJ5D8WKtXfKOijvhBDoGFI0r8fJMnSmBCatvvefl'}]




SECRET_ACCESS2 = [
    {'acc': 'AKIAIK6QCUBLIFFRPSPA',
  'sec': 'nDSHZOLFcGAnoWfFseohb/aRkluUthdcqmz61Yzw'},
 {'acc': 'AKIAIEH6LNUK425Y7Q2Q',
  'sec': 'QqBejVRxyQU4ydefT0WHzvf/HKNwasoCk583qZZf'},
 {'acc': 'AKIAJDZNROKLVJKUCI3Q',
  'sec': 'SftKU70LhXFT8nnkt0efta845Lo5C4vFkiM7fiGT'},
 {'acc': 'AKIAIGNDPDGRS4QFNKJA',
  'sec': 'phs/FruDrwPMXKqPfDRExOqXAeiXjli0GIse7eG4'},
 {'acc': 'AKIAIO35ODXH6KSCGHEQ',
  'sec': 'b9gTPlw23p46kb1719hhnxa1rB2JdaDFLjHXzyxK'},
 {'acc': 'AKIAJLP7FULC4DHGHTRA',
  'sec': '+3xyKrpe6J1bWIXNsqzl74FABQjVoMqD3a9d3gjL'},
 {'acc': 'AKIAJQWGOK3GT64YEVUA',
  'sec': 'VTit0mCnvc9Kb+t2rCc6RvhuZDILvvZTLfmM/5ss'},
 {'acc': 'AKIAI5G5JMCZTPPU5BVA',
  'sec': 'm24TTHYF6xq2XWkaRrxCGRVPE9zdJmevIP8rBQY9'},
 {'acc': 'AKIAJ4GMCCCQUV4TS5ZQ',
  'sec': '2bzVtcjzrrJNmK+aegXCqEOFF9i7z0VmgEcB/6JD'},
 {'acc': 'AKIAIYZR5YDBUNINHW4A',
  'sec': 'L99ZCVxK2+1hj5ENMFzgQgJCYGRlTbwc4pxLBj6r'},
 {'acc': 'AKIAJ4YAHRAVB5A6XMSA',
  'sec': '1f+lsRmRWTcAZ0nBO1VmddbX0bnjJ0lC1v3kn7fJ'},
 {'acc': 'AKIAJLRGLSQAR2DAHX2A',
  'sec': 'g01XrWzOd0aawqhUIWVWT8qF7LgdwjlaZobPJK3P'},
 {'acc': 'AKIAIAHJLZ25OOBGIHEQ',
  'sec': 'dwuvlTagw89XbKh7Z2kJHvf0iO5PAJX2z9MrHAyn'},
 {'acc': 'AKIAJODO3EBT6OTMZBDA',
  'sec': '3SpWghDaX7w3vaLGadcFpdl14YHO+fByggNEfAcM'},
 {'acc': 'AKIAJOJEYRHBGOXV6C4A',
  'sec': 'CDukFgMlCf8f43YzM5vkmZduVY2KZ4qV5muxGxOt'},
 {'acc': 'AKIAJQ4QWRPI3437W2YQ',
  'sec': '5AXyllIiUM1tTdNqjTMfITwLH3Q36zRPygm8gBQK'},
 {'acc': 'AKIAJF4RVJI57Y5CJFTQ',
  'sec': '2/Fy12c8ArZMH1VmxYDzSgYdQrPRL7ebilSkRYX6'},
 {'acc': 'AKIAIQWTSSFPM6F36HSA',
  'sec': 'zfR7f7SC5mW2dvlp5HuNHq5cTnUQaOWrQ3clTpdM'},
 {'acc': 'AKIAIU6PU2EITQXB2PTA',
  'sec': 'x3+buQrzOtcssayyobXkFuLFn4+GJpsKEzLPG98R'},
 {'acc': 'AKIAILUTCTZ7OYFLAVTA',
  'sec': 'rerTdWAVXsflW0ecaMcv/E9U0Ul/pOm+75y1hWjE'},
 {'acc': 'AKIAJJUA3YRNNXBNG3JA',
  'sec': '8dCzgMWYd6pkq+tJI/+zvfR+rpyDFqps53oagCL8'},
 {'acc': 'AKIAIIZHYX52IEM757SA',
  'sec': '2vDLb9/lOB3900RgRsAoIK7bHEscj6ixV2E3Z/+g'},
 {'acc': 'AKIAJ7RNMZPI7CZ4SZZA',
  'sec': 'sTesLlNQK6sWe7ebaxfns+GBSHrIffS6bhOE1b/y'},
 {'acc': 'AKIAINEXL7ECLQOS2MKA',
  'sec': 'fQg5qE7ARMsfZIBMHNOD0F6T8SiQ4RvNVDKVTv1a'},
 {'acc': 'AKIAID7EQCA2JIQWPFQA',
  'sec': 'NwmaPfgSAiE4cC+UQbASZ/KxFKp+oKMT/dUKPr0n'},
 {'acc': 'AKIAJ4JYQLHTWDIY5BMQ',
  'sec': 'PJ5D8WKtXfKOijvhBDoGFI0r8fJMnSmBCatvvefl'},
 {'acc': 'AKIAJ2LFAUZZAQSIJ2CQ',
  'sec': 'GOdwJkXi5CuezGnKjytdaGs7Vf291VcjkyW2GXPO'},
 {'acc': 'AKIAJLE6L62NGFVLJDIA',
  'sec': 'gIttrmlGWbm8HrIMnL9DCquGdM7t70S1YiaW02ll'}]


LOCALE_ACCESS = {'ca': SECRET_ACCESS2,
                 'de': SECRET_ACCESS1,
                 'es': SECRET_ACCESS1,
                 'fr': SECRET_ACCESS1,
                 'it': SECRET_ACCESS1,
                 'jp': SECRET_ACCESS2,
                 'mx': SECRET_ACCESS2,
                 'uk': SECRET_ACCESS1,
                 'us': SECRET_ACCESS2
 }



REQUEST_LOCALE_SEQUENCE = ['uk', 'ca', 'de','jp','us', 'mx','es','it','fr']

